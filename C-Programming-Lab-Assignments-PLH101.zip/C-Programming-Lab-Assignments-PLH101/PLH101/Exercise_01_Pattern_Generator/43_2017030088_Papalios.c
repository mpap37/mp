#include <stdio.h>
#include <stdlib.h>

int main()
{


    int number,lines,spots,NUMBER;

do{
        printf("give me a number between 1 to 15\n");
        scanf("%d", &number);

 while (number=0 || number> 15)
    {
        printf("another number\n");
        scanf("%d", &number);
    }


    NUMBER=1;
   if (number>0)

           for (lines=1; lines<=number; lines++)
        {

          for(spots=number; spots>=lines; spots--)
           {

          printf("%d ", NUMBER);
          NUMBER++;
           }

        printf("\n");

        }

    } while (number>0);
    return 0;
}
