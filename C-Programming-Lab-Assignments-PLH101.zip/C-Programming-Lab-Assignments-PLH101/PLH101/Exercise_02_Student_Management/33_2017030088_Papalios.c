#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SIZE_ACRONYM 10

typedef struct student {
char school[MAX_SIZE_ACRONYM];
int code;
float grade;
} Student;

void readStudents(Student *students,int size);
float averageGrade(Student *students, int size, char *theSchool);
void printStudentsBelowAverage(Student *students, char *theSchool, int size, float average);

int main() {

int numberofstudents;
float averagegrade;
char theSchool[MAX_SIZE_ACRONYM];
Student*students;

printf ("How many students?");
scanf ("%d", &numberofstudents);
getchar();

students=(Student*)malloc(numberofstudents*sizeof(Student));

readStudents (students,numberofstudents);

printf("\nGive the school you are interested in:");
scanf ("%s", &theSchool[MAX_SIZE_ACRONYM]);

averagegrade=averageGrade (students,numberofstudents,theSchool);

printStudentsBelowAverage(students,theSchool,numberofstudents,averagegrade);

free(students);

return 0;
}


 void printStudentsBelowAverage(Student *students, char *theSchool, int size, float average)
{
    int i;
    for (i=0; i<size; i++)
    {
        if (students[i].school==theSchool && students[i].grade<average)
           printf ("\nStudent code: %d Student grade: %f", students[i].code, students[i].grade);
    }
}


void readStudents(Student *students,int size)
{
    int i;
    for (i=0; i< size; i++)
    {
        printf ("\nStudent school:");
        gets(students[i].school);
        printf ("\nStudent code:");
        scanf("%d", &students[i].code);
        printf ("\nStudent grade:");
        scanf ("%f", &students[i].grade);
        getchar();

    }
}


float averageGrade(Student *students, int size, char *theSchool)
{
    int i,n;
    float averagegrade;
    n=0;
    averagegrade=0.0;

    for (i=0; i<size; i++)
    {
        if (students[i].school==theSchool)
        {  n=n+1;
           averagegrade=(averagegrade+ students[i].grade)/n;
        }
    }
    printf ("%f", averagegrade);
    return averagegrade;
}
