# PLH101: Introduction to Programming (C) - Lab Assignments

This repository contains two C programming assignments developed as part of the **PLH101** Technical university of Crete course. The projects focus on algorithmic logic, input validation, dynamic memory management, and data structures. 

---

Project Overview

### 1. Triangular Number Pattern Generator
A console application that generates a specific geometric pattern of sequential numbers based on user input. 

Logic: The user provides an integer $n$ between 1 and 15. [cite: 1]
Validation: Includes a loop to handle invalid inputs (0 or >15) and prompts the user until a valid number or a negative exit value is provided. [cite: 2]
Output: Generates a downward-pointing triangle where each line contains fewer sequential numbers than the previous. [cite: 4, 5, 6, 7]
Looping: The program restarts automatically after each print until a negative number is entered. [cite: 14]

### 2. Dynamic Student Records Manager
A more advanced utility that manages student data using custom structures and dynamic memory allocation. 

Data Structure: Utilizes a `struct` to store school acronyms (max 10 chars), unique student IDs, and graduation grades. [cite: 17, 18]
Memory Management: Uses `malloc` to allocate memory based on the exact number of students requested and `free` to release it before termination. [cite: 20, 25]
Functional Features: [cite: 21, 23, 24]
    `readStudents`: Populates the student array from user input.
    `averageGrade`: Calculates the mean grade for a specific school.
    `printStudentsBelowAverage`: Identifies and lists students whose performance is below their school's average.

Technical Stack
Language: C (Standard I/O, Stdlib, String libraries) [cite: 16]
Concepts: Nested Loops, Pointers, Structs, Dynamic Memory Allocation (`malloc`/`free`). [cite: 3, 17, 20, 25]
